Symfony Guest Book Application
==============================

This is a simple guest book application built with Symfony. It is used to demonstrate the usage of Symfony during the tutorial of CSCI 4140: Open-Source Software Project Development (Spring 2015). The tutorial slides can be found on <http://mtyiu.github.io/csci4140-spring15/>.

Before using this application, please run ``composer install`` to install all dependencies.
