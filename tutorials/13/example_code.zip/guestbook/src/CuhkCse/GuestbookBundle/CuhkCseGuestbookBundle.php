<?php

namespace CuhkCse\GuestbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CuhkCseGuestbookBundle extends Bundle
{
}
