<?php

/* CuhkCseGuestbookBundle:Default:index.html.twig */
class __TwigTemplate_d42f3be5547cdf1683efc39fcca410297077dea4ca87fcf8ccf7177b9084e168 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<meta charset=\"utf-8\">
\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
\t\t<title>Symfony Demo Application: Guest Book</title>
\t\t<link href=\"https://bootswatch.com/paper/bootstrap.min.css\" rel=\"stylesheet\">
\t\t<style>
\t\t\t.row {
\t\t\t\tmargin-top: 20px;
\t\t\t\tmargin-bottom: 20px;
\t\t\t}
\t\t\t.by {
\t\t\t\tpadding: 10px;
\t\t\t}
\t\t\t.message {
\t\t\t\tbackground-color: #fbfbfb;
\t\t\t\tborder: 1px dotted #eee;
\t\t\t\tpadding: 10px;
\t\t\t}
\t\t</style>
\t\t<!--[if lt IE 9]>
\t\t\t<script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
\t\t\t<script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
\t\t<![endif]-->
\t</head>
\t<body>
\t\t<div class=\"container\">
\t\t\t<h3>Symfony Demo Application: Guest Book</h3>
\t\t\t<hr />
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-4 col-md-offset-8\">
\t\t\t\t\t<a href=\"";
        // line 34
        echo $this->env->getExtension('routing')->getPath("cuhk_cse_guestbook_form");
        echo "\" class=\"btn btn-success btn-block\">Leave a Message!</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        // line 37
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["messages"]) ? $context["messages"] : $this->getContext($context, "messages")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["m"]) {
            // line 38
            echo "\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-md-3 by\">
\t\t\t\t\t\t<strong>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "name", array()), "html", null, true);
            echo "</strong><br />
\t\t\t\t\t\t<a href=\"mailto:";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "email", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "email", array()), "html", null, true);
            echo "</a>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-md-9 message\">
\t\t\t\t\t\t<strong>Message</strong> <a href=\"";
            // line 44
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("cuhk_cse_guestbook_form", array("id" => $this->getAttribute($context["m"], "id", array()))), "html", null, true);
            echo "\">[Edit]</a><br />
\t\t\t\t\t\t";
            // line 45
            echo twig_escape_filter($this->env, $this->getAttribute($context["m"], "message", array()), "html", null, true);
            echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 49
            echo "\t\t\t\t<div class=\"row\">
\t\t\t\t\t<p class=\"lead text-center\">No messages</p>
\t\t\t\t</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['m'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "\t\t</div>
\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
\t\t<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js\"></script>
\t</body>
</html>";
    }

    public function getTemplateName()
    {
        return "CuhkCseGuestbookBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 53,  94 => 49,  85 => 45,  81 => 44,  73 => 41,  69 => 40,  65 => 38,  60 => 37,  54 => 34,  19 => 1,);
    }
}
