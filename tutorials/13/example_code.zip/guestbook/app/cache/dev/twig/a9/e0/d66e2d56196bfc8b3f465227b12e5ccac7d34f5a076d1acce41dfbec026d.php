<?php

/* CuhkCseGuestbookBundle:Default:form.html.twig */
class __TwigTemplate_a9e0d66e2d56196bfc8b3f465227b12e5ccac7d34f5a076d1acce41dfbec026d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<meta charset=\"utf-8\">
\t\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
\t\t<title>Symfony Demo Application: Guest Book</title>
\t\t<link href=\"https://bootswatch.com/paper/bootstrap.min.css\" rel=\"stylesheet\">
\t\t<style>
\t\t\tul {
\t\t\t\tlist-style-type: none;
\t\t\t\tpadding: 0;
\t\t\t}
\t\t</style>
\t\t<!--[if lt IE 9]>
\t\t\t<script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
\t\t\t<script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
\t\t<![endif]-->
\t</head>
\t<body>
\t\t<div class=\"container\">
\t\t\t<h3>Symfony Demo Application: Guest Book</h3>
\t\t\t<hr />
\t\t\t";
        // line 24
        if ((array_key_exists("success", $context) && (isset($context["success"]) ? $context["success"] : $this->getContext($context, "success")))) {
            // line 25
            echo "\t\t\t<div class=\"alert alert-success\">
\t\t\t\t<i class=\"glyphicon glyphicon-ok\"></i> The message is submitted successfully!
\t\t\t</div>
\t\t\t";
        }
        // line 29
        echo "\t\t\t";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("class" => "form-horizontal")));
        echo "
\t\t\t\t";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-sm-2 control-label\">Name</label>
\t\t\t\t\t<div class=\"col-sm-10\">
\t\t\t\t\t\t";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
\t\t\t\t\t\t<span class=\"text-danger\">";
        // line 35
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors', array("attr" => array("class" => "text-danger")));
        echo "</span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-sm-2 control-label\">Email</label>
\t\t\t\t\t<div class=\"col-sm-10\">
\t\t\t\t\t\t";
        // line 41
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
\t\t\t\t\t\t<span class=\"text-danger\">";
        // line 42
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'errors', array("attr" => array("class" => "text-danger")));
        echo "</span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t<label class=\"col-sm-2 control-label\">Message</label>
\t\t\t\t\t<div class=\"col-sm-10\">
\t\t\t\t\t\t";
        // line 48
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "message", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
\t\t\t\t\t\t<span class=\"text-danger\">";
        // line 49
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "message", array()), 'errors', array("attr" => array("class" => "text-danger")));
        echo "</span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-md-2 col-md-offset-3\">
\t\t\t\t\t\t<a href=\"";
        // line 54
        echo $this->env->getExtension('routing')->getPath("cuhk_cse_guestbook_homepage");
        echo "\" class=\"btn btn-block btn-info\">Back to Index</a>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t";
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'widget', array("attr" => array("class" => "btn btn-block btn-success")));
        echo "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-md-2\">
\t\t\t\t\t\t";
        // line 60
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "reset", array()), 'widget', array("attr" => array("class" => "btn btn-block btn-danger")));
        echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t";
        // line 63
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
\t\t</div>
\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
\t\t<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js\"></script>
\t</body>
</html>";
    }

    public function getTemplateName()
    {
        return "CuhkCseGuestbookBundle:Default:form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 63,  114 => 60,  108 => 57,  102 => 54,  94 => 49,  90 => 48,  81 => 42,  77 => 41,  68 => 35,  64 => 34,  57 => 30,  52 => 29,  46 => 25,  44 => 24,  19 => 1,);
    }
}
